import hero_skill from "../../consts/hero_skill.json";
import item from "../../consts/item.json";


export default function HeroInfo({ name }) {



    return (
		<div
		>
			
		</div>
	);
}
