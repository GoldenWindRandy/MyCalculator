import style from "./hero.module.css"

export default function HeroIcon({ ename, name }) {

    return (
		<div
			style={{
				display: "flex",
				flexDirection: "column",
				alignItems: "center",
				marginBottom: "16px",
			}}
            className={style.icon}
		>
			<div
				style={{
					width: "100px",
					height: "100px",
					border: "1px solid black",
					borderRadius: "50%",
					margin: "16px",
					background: `url(//game.gtimg.cn/images/yxzj/img201606/heroimg/${ename}/${ename}-smallskin-1.jpg)`,
					backgroundSize: "cover",
				}}
			></div>
			<span>{name}</span>
		</div>
	);
}
