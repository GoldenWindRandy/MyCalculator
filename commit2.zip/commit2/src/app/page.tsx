
import styles from "./page.module.css";
import hero_skill from "../consts/hero_skill.json";
import HeroIcon from "./hero/hero";

export default function Home() {
	// const heroNames = Object.keys(hero_skill);
	const name = "廉颇";
	const ename = 105;
	return (
		<main className={styles.main}>
			<HeroIcon
				ename={ename}
				name={name}
			></HeroIcon>
			{/* {heroNames.map((name) => {
				const ename = (hero_skill as any)[name].ename;
				return (
					<HeroIcon
						ename={ename}
						name={name}
					></HeroIcon>
				);
			})} */}
		</main>
	);
}
