import pandas
import requests
import re
import json
from bs4 import BeautifulSoup, Comment
url = 'https://pvp.qq.com/web201605/js/herolist.json'
headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
}

response = requests.get(url, headers = headers)
herolist = json.loads(response.text)
enames = []
for item in herolist:
    herolist_ename = item['ename']
    enames.append(herolist_ename)
a = 0
base_url = "https://pvp.qq.com/web201605/herodetail/{}.shtml"
hero_skill_dict = {}
for ename in enames:
    skill_dict = {}
    true_url = base_url.format(ename)
    # 技能图片路径
    skill_src = []
    response = requests.get(true_url)
    html_content = response.content
    soup = BeautifulSoup(html_content, 'html.parser')
    # 找到ul标签
    ul_tag = soup.find('ul', {'class': 'skill-u1'})  # 替换成你实际的ul标签的class名
    # 遍历li标签
    for li_tag in ul_tag.find_all('li'):
        img_tag = li_tag.find('img')
        if img_tag:
            src = img_tag.get('src')
            skill_src.append(src)

    ul_tag = soup.find('ul', {'class': 'cover-list'})  # 替换成你实际的ul标签的class名
    # 遍历li标签
    five_d = []
    for li_tag in ul_tag.find_all('li'):
        i_tag = li_tag.find('i')
        if i_tag:
            style = i_tag.get('style')
            five_d.append(style.split(":")[1][:-1])

    # 推荐装备
    ul_tag = soup.find('ul', {'class': 'equip-list fl'})  # 替换成你实际的ul标签的class名
    recommand_equip = ul_tag.get("data-item").split("|")

    r = requests.get(true_url, headers = headers)
    r.encoding = "gbk"
    names = re.compile('<label>(.*?)</label>')
    name = names.findall(r.text)[0]
    skills = re.compile('<p class="skill-desc">(.*?)</p>', re.S)
    titles = re.compile('<h3 class="cover-title">(.*?)</h3>', re.S)
    pattern = re.compile(r'<p class="skill-name"><b>(.*?)</b><span>(.*?)</span><span>(.*?)</span></p>', re.S)

    # 进行匹配
    result = re.findall(pattern, r.text)
    skill_dict["skills"] = []
    for item in result:
        b_content, span1_content, span2_content = item
        tmp = {
            "cost": span1_content,
            "cold": span2_content,
            "name": b_content,
        }
        skill_dict["skills"].append(tmp)

    skill_arr = skills.findall(r.text)
    title = titles.findall(r.text)
    for i, skill in enumerate(skill_dict["skills"]):
        skill["desc"] = skill_arr[i]
        skill["src"] = skill_src[i]
    skill_dict["title"] = title[0]
    skill_dict["ename"] = ename
    skill_dict["equips"] = recommand_equip
    skill_dict["fiveD"] = five_d
    hero_skill_dict[name] = skill_dict
    # a+=1
    # if a > 1:
    #     break
    
json_data = json.dumps(hero_skill_dict, ensure_ascii=False, indent=4)
with open('./my_data.json', 'w', encoding='utf-8') as json_file:
    json_file.write(json_data)
print("over")

