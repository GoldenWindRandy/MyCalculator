import json

data = []
with open('./item.json', 'r', encoding='utf-8') as json_file:
    data = json.load(json_file)

res = {}

for item in data:
    res[item["item_id"]] = item


json_data = json.dumps(res, ensure_ascii=False, indent=4)
with open('./item_dict.json', 'w', encoding='utf-8') as json_file:
    json_file.write(json_data)
