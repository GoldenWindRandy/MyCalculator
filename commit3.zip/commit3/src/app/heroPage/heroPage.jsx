import hero_skill from "../../consts/hero_skill.json";
import item from "../../consts/item_dict.json";
import Skill from "./skill";
import HeroInfo from "./heroInfo";
import style from "./heroPage.module.css";

export default function HeroPage({ name, onclick }) {
	const hero_info = hero_skill[name];

	return (
		<div style={{ width: "100%" }}>
			<div
				className={style.pointer}
				style={{
					position: "absolute",
					top: "48px",
					left: "64px",
					width: "64px",
					height: "32px",
					textAlign: "center",
					lineHeight: "32px",
					backgroundColor: "#0066CC",
					color: "white",
					borderRadius: "16px",
				}}
				onClick={onclick}
			>
				返回
			</div>
			<div
				style={{
					display: "flex",
					flexDirection: "row",
					width: "100%",
					height: "256px",
				}}
			>
				<HeroInfo
					hero_info={hero_info}
					name={name}
				></HeroInfo>
				<Skill skills={hero_info.skills}></Skill>
			</div>
			<div>
				出装
				{hero_info.equips.map((equip) => {
					return <div key={equip}>{equip}</div>;
				})}
			</div>
		</div>
	);
}
