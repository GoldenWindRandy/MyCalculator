"use client"; 
import styles from "./page.module.css";
import hero_skill from "../consts/hero_skill.json";
import HeroIcon from "./heroIcon/heroIcon";
import HeroPage from "./heroPage/heroPage"
import { useState } from "react";

export default function Home() {
	// const heroNames = Object.keys(hero_skill);
	const name = "廉颇";
	const ename = 105;
	const [inIconPage, setInIconPage] = useState(true);

	const handleClick = (value: boolean) => {
		setInIconPage(value);
	}

	return (
		<main className={styles.main}>
			{
				inIconPage ?
				<HeroIcon
					onclick={() => {
						handleClick(false);
					}}
					ename={ename}
					name={name}
				></HeroIcon>
				: 
				<HeroPage
					name={name}
					onclick={() => {
						handleClick(true);
					}}
				></HeroPage>
			}

			{/* {heroNames.map((name) => {
				const ename = (hero_skill as any)[name].ename;
				return (
					<HeroIcon
						ename={ename}
						name={name}
					></HeroIcon>
				);
			})} */}
		</main>
	);
}
